import 'package:flutter/material.dart';
import 'package:flutterapp/w3safetyapp/generatedstyleguidewidget/GeneratedStyleGuideWidget.dart';
import 'package:flutterapp/w3safetyapp/generatedserviceswidget/GeneratedServicesWidget.dart';
import 'package:flutterapp/w3safetyapp/generatedloginpagewidget/GeneratedLoginpageWidget.dart';
import 'package:flutterapp/w3safetyapp/generatedstartwidget/GeneratedStartWidget.dart';
import 'package:flutterapp/w3safetyapp/generatedspammerlistwidget/GeneratedSpammerListWidget.dart';
import 'package:flutterapp/w3safetyapp/generatedblogswidget1/GeneratedBlogsWidget1.dart';
import 'package:flutterapp/w3safetyapp/generatedvideocontentswidget/GeneratedVideoContentsWidget.dart';
import 'package:flutterapp/w3safetyapp/generatedcybersecuritytoolswidget1/GeneratedCyberSecurityToolsWidget1.dart';
import 'package:flutterapp/w3safetyapp/generatedlegalsupportwidget1/GeneratedLegalSupportWidget1.dart';
import 'package:flutterapp/w3safetyapp/generatedonlineconsultancywidget1/GeneratedOnlineConsultancyWidget1.dart';
import 'package:flutterapp/w3safetyapp/generatedframe25widget/GeneratedFrame25Widget.dart';
import 'package:flutterapp/w3safetyapp/generatedline1widget9/GeneratedLine1Widget9.dart';

void main() {
  runApp(W3SafetyApp());
}

class W3SafetyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedStartWidget',
      routes: {
        '/GeneratedStyleGuideWidget': (context) => GeneratedStyleGuideWidget(),
        '/GeneratedServicesWidget': (context) => GeneratedServicesWidget(),
        '/GeneratedLoginpageWidget': (context) => GeneratedLoginpageWidget(),
        '/GeneratedStartWidget': (context) => GeneratedStartWidget(),
        '/GeneratedSpammerListWidget': (context) =>
            GeneratedSpammerListWidget(),
        '/GeneratedBlogsWidget1': (context) => GeneratedBlogsWidget1(),
        '/GeneratedVideoContentsWidget': (context) =>
            GeneratedVideoContentsWidget(),
        '/GeneratedCyberSecurityToolsWidget1': (context) =>
            GeneratedCyberSecurityToolsWidget1(),
        '/GeneratedLegalSupportWidget1': (context) =>
            GeneratedLegalSupportWidget1(),
        '/GeneratedOnlineConsultancyWidget1': (context) =>
            GeneratedOnlineConsultancyWidget1(),
        '/GeneratedFrame25Widget': (context) => GeneratedFrame25Widget(),
        '/GeneratedLine1Widget9': (context) => GeneratedLine1Widget9(),
      },
    );
  }
}
